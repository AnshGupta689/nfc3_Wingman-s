<?php
mysql_connect('localhost','root','');
mysql_select_db('bestcom_tech') or die('Cant connect to db');
